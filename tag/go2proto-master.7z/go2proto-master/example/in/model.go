package in

type (
	Group1 struct {
		Str1 string
		Str2 string
		Int3 int64
		Str4 string
		Int5 int64
	}
	System struct {
		Group1 Group1
	}
)
